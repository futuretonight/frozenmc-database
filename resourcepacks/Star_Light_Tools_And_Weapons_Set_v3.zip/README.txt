Terms of Use.
If you have used our products, it means you agree to the terms of service, which apply to our products.

1.You may alter the configuration or add-ons to fit your style or server needs, but under no circumstance make those changes available for purchase.
2.The products are created by 3bstudio, who is the copyright owner of the products.
3.You cannot put our products on sale anywhere and you cannot sell our products to anyone.
4.If there are any issues or bugs after modifying the configuration, we will not take any responsibility for them, and it will be solely your server's responsibility.

Test on 1.20.2

Requirement:
  • Itemsadder (with LoneLibs and ProtocolLibs) or Oraxen

How to install:
  Installation Pack:
    STEP 1:
    • Please double-check to ensure that you have installed the plugins as we have specified.
    STEP 2:
    • Copy both "Itemsadder" or "Oraxen" into your plugins folder of your server.
    STEP 3:
    • use the command '/ia zip' or '/o reload all'.
    STEP 4:
    • enjoy!!

--------------------------

Create by 3BSTUDIO

--------------------------

The channel to inquire about problems : https://discord.gg/4c2jvJXACQ

Thankyou For Purchase


# 4403595JB